treeImbalance
=============

An R package for detecting asymmetry in time-sampled phylogenetic trees.

To install, use:

```
library(devtools)
install_git("http://github.com/bdearlove/treeImbalance.git")
```
